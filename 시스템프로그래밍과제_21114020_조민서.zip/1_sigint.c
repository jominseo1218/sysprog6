/*
 * 1_sigint.c — Ctrl+C(SIGINT)를 세 번 눌러야 종료한다
 *
 * [원본에서 바꾼 것]
 *   원본은 플래그 하나(got_sigint)를 켜고 첫 SIGINT 에 바로 끝났다.
 *   여기서는 플래그를 카운터로 바꿔 누른 횟수를 세고, 세 번째에 정리 메시지를 낸다.
 *
 * [핵심 개념]
 *   핸들러 안에서는 아무 함수나 부르면 안 된다 — 중간에 끼어들어 실행되기 때문이다.
 *   그래서 핸들러는 카운터만 올리고, 출력과 종료 판단은 모두 main 에서 한다.
 *   카운터는 volatile sig_atomic_t 로 둔다.
 *     volatile       — 컴파일러가 레지스터에 캐싱해 루프가 안 끝나는 것을 막는다
 *     sig_atomic_t   — 시그널이 끼어들어도 읽기/쓰기가 쪼개지지 않는다
 *   출처: man 2 sigaction, man 7 signal-safety
 *
 * [컴파일·실행]
 *   gcc -Wall -Wextra -o 1_sigint 1_sigint.c
 *   ./1_sigint      # Ctrl+C 를 세 번 눌러 본다
 */
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#define NEED 3   /* 종료까지 필요한 Ctrl+C 횟수 */

/* 핸들러와 main 이 함께 보는 변수. 중간에 바뀔 수 있으므로 volatile 을 붙인다. */
static volatile sig_atomic_t count = 0;

static void handler(int sig)
{
    (void)sig;   /* 인자를 쓰지 않을 때 경고를 막는 관용적 표현 */
    count++;     /* 카운터만 올린다 — printf 같은 함수는 여기서 부르지 않는다 */
}

int main(void)
{
    struct sigaction sa;
    int shown = 0;   /* main 이 이미 화면에 출력한 횟수 */

    sa.sa_handler = handler;   /* SIGINT 가 오면 기본 동작(종료) 대신 이 함수를 부르게 한다 */
    sigemptyset(&sa.sa_mask);  /* 핸들러 도중 추가로 막을 시그널은 없다 */
    sa.sa_flags = 0;           /* 특별한 동작(SA_RESTART 등) 없이 기본값 사용 */

    if (sigaction(SIGINT, &sa, NULL) == -1) {   /* 세 번째 NULL: 이전 설정은 저장하지 않는다 */
        perror("sigaction");
        return 1;
    }

    printf("Ctrl+C 를 %d 번 누르면 종료합니다 (PID %d)\n", NEED, getpid());

    while (count < NEED) {
        /*
         * 핸들러가 올려 둔 만큼만 여기서 출력한다.
         * count 는 언제든 바뀔 수 있으므로 shown 과 비교하며 따라잡는 방식으로 읽는다.
         */
        while (shown < count && shown < NEED) {
            shown++;
            printf("[%d/%d] SIGINT 를 받았습니다. %d 번 남았습니다.\n",
                   shown, NEED, NEED - shown);
        }

        if (count < NEED)
            pause();   /* 시그널이 올 때까지 잠들어 있는다(CPU 를 쓰지 않는다) */
        /*
         * 참고: 이 검사와 pause() 사이에 시그널이 오면 그 한 번을 놓칠 수 있다(경쟁 조건).
         * 엄밀하게는 sigsuspend() 로 "마스크 해제와 대기"를 원자적으로 해야 한다.
         * 이 실습에서는 한 번 더 누르면 깨어나므로 원본과 같이 pause() 를 유지했다.
         */
    }

    /* 마지막 한 번의 출력이 남아 있으면 처리한다 */
    while (shown < NEED) {
        shown++;
        printf("[%d/%d] SIGINT 를 받았습니다.\n", shown, NEED);
    }

    printf("\nSIGINT 를 %d 번 받았습니다. 정리하고 종료합니다.\n", NEED);
    return 0;
}
