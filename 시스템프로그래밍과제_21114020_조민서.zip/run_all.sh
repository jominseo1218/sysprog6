#!/usr/bin/env bash
#
# run_all.sh — 6주차 시그널 실습 3과제 실행 스크립트
#
#   ./run_all.sh          대화형: 직접 Ctrl+C 를 눌러 가며 실행 (제출 캡처용 권장)
#   ./run_all.sh --auto   자동: kill 로 시그널을 대신 보내 무인 실행, logs/ 에 저장

set -u
cd "$(dirname "$0")" || exit 1

C='\033[1;36m'; G='\033[1;32m'; Y='\033[1;33m'; N='\033[0m'
AUTO=0
[ "${1:-}" = "--auto" ] && AUTO=1

bar() { echo; echo -e "${C}============================================================${N}";
        echo -e "${C} $1${N}";
        echo -e "${C}============================================================${N}"; }

bar "0. 환경 점검"
if ! command -v gcc >/dev/null 2>&1; then
    echo -e "${Y}gcc 가 없습니다. 먼저 설치하세요:${N}"
    echo "    sudo apt update && sudo apt install -y build-essential"
    exit 1
fi
echo "gcc : $(gcc --version | head -1)"
echo "커널: $(uname -sr)"

bar "1. 빌드"
# Makefile 은 확장자가 없어 원격 전송이 막히므로, 없으면 여기서 만든다
if [ ! -f Makefile ]; then
    echo "Makefile 이 없어 새로 생성합니다."
    printf '%s\n' \
'CC      = gcc' \
'CFLAGS  = -Wall -Wextra' \
'TARGETS = 1_sigint alarm 3_signal_block' \
'' \
'all: $(TARGETS)' \
'' \
'1_sigint: 1_sigint.c' \
'	$(CC) $(CFLAGS) -o $@ $<' \
'' \
'alarm: 2_alarm.c' \
'	$(CC) $(CFLAGS) -o $@ $<' \
'' \
'3_signal_block: 3_signal_block.c' \
'	$(CC) $(CFLAGS) -o $@ $<' \
'' \
'clean:' \
'	rm -f $(TARGETS)' \
'' \
'.PHONY: all clean' > Makefile
fi

make clean >/dev/null 2>&1
make || { echo -e "${Y}빌드 실패${N}"; exit 1; }
echo -e "${G}빌드 성공 — 경고 0건${N}"

# ------------------------------------------------------------------ 대화형
if [ "$AUTO" -eq 0 ]; then
    bar "과제 1 — Ctrl+C 를 세 번 눌러야 종료"
    echo "Ctrl+C 를 세 번 누르세요. Enter 로 시작..."; read -r _
    ./1_sigint

    bar "과제 2 — 반복 타이머 (./alarm 2 5)"
    echo "2초 간격 5회, 약 10초 걸립니다. Enter 로 시작..."; read -r _
    ./alarm 2 5

    bar "과제 3 — 시그널 막아 보기"
    echo "구간 1(5초)은 열림, 구간 2(8초)는 막힘입니다."
    echo "'막힘...' 이 뜨면 Ctrl+C 를 4~5번 누르세요. Enter 로 시작..."; read -r _
    ./3_signal_block

    bar "완료"
    echo "이 화면을 캡처해 screenshots/ 에 넣으세요."
    exit 0
fi

# ------------------------------------------------------------------ 자동
mkdir -p logs

bar "과제 1 — Ctrl+C 세 번 (자동: kill -INT 3회)"
./1_sigint 2>&1 | tee logs/1_sigint.log &
sleep 1; P=$(pgrep -n -x 1_sigint)
for _ in 1 2 3; do kill -INT "$P" 2>/dev/null; sleep 0.6; done
wait

bar "과제 2 — 반복 타이머 (./alarm 2 5)"
./alarm 2 5 2>&1 | tee logs/2_alarm.log

bar "과제 3 — 시그널 블로킹 (자동: 막힌 구간에 kill -INT 5회)"
./3_signal_block 2>&1 | tee logs/3_block.log &
sleep 2; P=$(pgrep -n -x 3_signal_block)
kill -INT "$P" 2>/dev/null          # 구간 1(열림) — 즉시 전달
sleep 5                              # 구간 2(막힘) 진입 대기
for _ in 1 2 3 4 5; do kill -INT "$P" 2>/dev/null; sleep 0.4; done
wait

bar "완료"
echo "로그 저장됨:"; ls -1 logs/
echo
echo -e "${G}확인 사항${N}"
echo "  과제 1: SIGINT 3회 후 정리 메시지"
echo "  과제 2: 2초 간격 5회, 경과 시간이 2초씩 증가"
echo "  과제 3: 막힌 동안 5번 보냈지만 핸들러는 1번만 추가 호출"
