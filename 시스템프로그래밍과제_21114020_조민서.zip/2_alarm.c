/*
 * 2_alarm.c — 간격과 횟수를 받아 반복 타이머를 만든다
 *
 * [원본에서 바꾼 것]
 *   원본은 alarm(3) 으로 한 번만 울려 입력 시간 제한(타임아웃)을 구현했다.
 *   여기서는 명령행 인자로 간격과 반복 횟수를 받아 그 횟수만큼 반복해서 울린다.
 *
 * [핵심 개념]
 *   alarm(n) 은 n 초 뒤에 SIGALRM 을 "한 번" 보내도록 예약한다.
 *   시그널이 전달되는 순간 예약은 사라지므로, 반복하려면 핸들러가 처리한 뒤
 *   다시 alarm(간격) 을 걸어야 한다. (PPT 1.7절)
 *   alarm 은 프로세스당 하나뿐이라 새로 호출하면 이전 예약이 취소된다.
 *   핸들러 안에서 alarm() 을 부르는 것은 안전하다 — async-signal-safe 목록에 있다.
 *   반면 printf 는 안전하지 않으므로 출력은 main 에서 한다.
 *   출처: man 2 alarm, man 7 signal-safety
 *
 * [컴파일·실행]
 *   gcc -Wall -Wextra -o alarm 2_alarm.c
 *   ./alarm 2 5      # 2초 간격으로 5번 울린다
 */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>

static volatile sig_atomic_t ticks    = 0;   /* 지금까지 울린 횟수 */
static volatile sig_atomic_t interval = 0;   /* 다시 걸 간격(초) */
static volatile sig_atomic_t repeat   = 0;   /* 목표 반복 횟수 */

static void on_alarm(int sig)
{
    (void)sig;
    ticks++;

    /* 핵심: alarm 은 한 번만 울리므로 여기서 다시 걸어야 반복된다 */
    if (ticks < repeat)
        alarm((unsigned int)interval);
}

int main(int argc, char *argv[])
{
    struct sigaction sa;
    int shown = 0;
    time_t start;

    if (argc != 3) {
        fprintf(stderr, "사용법: %s <간격초> <반복횟수>\n", argv[0]);
        fprintf(stderr, "  예) %s 2 5\n", argv[0]);
        return 1;
    }

    interval = atoi(argv[1]);
    repeat   = atoi(argv[2]);

    /*
     * alarm(0) 은 "예약 취소"로 해석되어 타이머가 영영 울리지 않는다.
     * 그러면 아래 pause() 에서 멈춘 채 끝나지 않으므로 미리 걸러낸다.
     */
    if (interval <= 0 || repeat <= 0) {
        fprintf(stderr, "간격과 반복횟수는 1 이상의 정수여야 합니다.\n");
        return 1;
    }

    sa.sa_handler = on_alarm;   /* SIGALRM 이 오면 이 함수를 부르게 등록한다 */
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGALRM, &sa, NULL);

    printf("%d초 간격으로 %d번 울립니다 (PID %d)\n",
           (int)interval, (int)repeat, getpid());

    start = time(NULL);
    alarm((unsigned int)interval);   /* 첫 알람 예약 */

    while (ticks < repeat) {
        while (shown < ticks) {
            shown++;
            printf("[%d/%d] 알람 (경과 %ld초)\n",
                   shown, (int)repeat, (long)(time(NULL) - start));
        }

        if (ticks < repeat)
            pause();   /* 다음 SIGALRM 이 올 때까지 CPU 를 쓰지 않고 기다린다 */
    }

    while (shown < repeat) {
        shown++;
        printf("[%d/%d] 알람 (경과 %ld초)\n",
               shown, (int)repeat, (long)(time(NULL) - start));
    }

    printf("\n%d번 모두 울렸습니다. 종료합니다.\n", (int)repeat);
    return 0;
}
