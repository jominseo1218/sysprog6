/*
 * 3_signal_block.c — 잠깐 시그널을 막아 두고, 풀 때 전달되는지 확인한다
 *
 * [원본에서 바꾼 것]
 *   원본은 5초간 막고 "전달됨 / 아직 대기 중" 만 출력했다.
 *   여기서는 (1) 막기 전에도 눌러 볼 수 있는 구간을 두어 즉시 전달을 비교하고,
 *            (2) sigpending() 으로 대기 중인 시그널이 실제로 있는지 눈으로 확인하고,
 *            (3) 플래그를 카운터로 바꿔 "여러 번 눌러도 한 번만 전달된다" 를 증명한다.
 *
 * [핵심 개념]
 *   sigprocmask 로 시그널을 블록하면 그동안 오는 시그널은 버려지지 않고
 *   대기(pending)했다가, 풀어 주는 순간 전달된다.
 *   그런데 표준 시그널의 pending 은 "왔다/안 왔다" 한 비트뿐이다.
 *   막힌 동안 열 번 눌러도 풀면 한 번만 전달된다. (PPT 1.3절)
 *
 *   복원은 SIG_UNBLOCK 이 아니라 SIG_SETMASK 로 한다.
 *   SIG_UNBLOCK 은 원래부터 막혀 있던 시그널까지 풀어 버리기 때문이다.
 *   그래서 sigprocmask 의 세 번째 인자에 이전 마스크를 저장해 두었다가 통째로 되돌린다.
 *   출처: man 2 sigprocmask, man 2 sigpending
 *
 * [컴파일·실행]
 *   gcc -Wall -Wextra -o 3_signal_block 3_signal_block.c
 *   ./3_signal_block      # 막혀 있는 8초 동안 Ctrl+C 를 여러 번 눌러 본다
 */
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

static volatile sig_atomic_t got = 0;   /* 핸들러가 실제로 불린 횟수 */

static void handler(int sig) { (void)sig; got++; }

/* 지금 SIGINT 가 대기(pending) 중인지 확인해서 출력한다 */
static void show_pending(const char *label)
{
    sigset_t pending;

    if (sigpending(&pending) == -1) {
        perror("sigpending");
        return;
    }

    printf("  [%s] SIGINT 대기 상태: %s\n", label,
           sigismember(&pending, SIGINT) ? "대기 중(pending) 있음" : "없음");
}

int main(void)
{
    struct sigaction sa;
    sigset_t block, old;
    int i, shown = 0;

    sa.sa_handler = handler;   /* SIGINT 가 오면 이 함수를 부르도록 등록 (블록 여부와는 별개다) */
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL);

    /* ---- 구간 1: 막기 전 — 누르면 즉시 전달된다 ---- */
    printf("[구간 1] 아직 막지 않았습니다. Ctrl+C 를 눌러 보세요. (5초)\n");
    for (i = 5; i > 0; i--) {
        printf("  열림... %d\n", i);
        fflush(stdout);   /* 카운트다운이 버퍼에 쌓이지 않고 바로 보이게 한다 */
        sleep(1);

        while (shown < got) {   /* 새로 들어온 만큼만 알린다 */
            shown++;
            printf("  >>> 즉시 전달됨 (핸들러 %d회째)\n", shown);
        }
    }

    /* ---- SIGINT 를 막는다 ---- */
    sigemptyset(&block);         /* 빈 집합에서 시작 */
    sigaddset(&block, SIGINT);   /* SIGINT 하나만 넣는다 */

    /* SIG_BLOCK: 지금 마스크에 추가로 막는다. old 에는 원래 마스크가 저장된다. */
    if (sigprocmask(SIG_BLOCK, &block, &old) == -1) {
        perror("sigprocmask");
        return 1;
    }

    /* ---- 구간 2: 막힌 구간 ---- */
    printf("\n[구간 2] 지금부터 SIGINT 를 막습니다. Ctrl+C 를 여러 번 눌러 보세요. (8초)\n");
    for (i = 8; i > 0; i--) {
        printf("  막힘... %d  (핸들러 호출 누적 %d회)\n", i, (int)got);
        fflush(stdout);
        sleep(1);   /* 이 동안 SIGINT 가 와도 핸들러가 실행되지 않고 커널에 대기한다 */
    }

    printf("\n  마스크를 풀기 직전 점검:\n");
    show_pending("해제 전");

    /* ---- 구간 3: 원래 마스크로 복원 — 이 순간 대기 중이던 SIGINT 가 전달된다 ---- */
    printf("\n[구간 3] 막기를 풉니다.\n");
    sigprocmask(SIG_SETMASK, &old, NULL);   /* 세 번째 인자 NULL: 지금 마스크는 저장할 필요 없다 */

    show_pending("해제 후");
    while (shown < got) {
        shown++;
        printf("  >>> 대기하던 시그널 전달됨 (핸들러 %d회째)\n", shown);
    }

    printf("\n핸들러가 불린 총 횟수: %d회\n", (int)got);
    printf("막힌 동안 여러 번 눌러도 풀렸을 때 한 번만 전달됩니다.\n");
    printf("표준 시그널의 pending 은 한 비트뿐이라 중복이 합쳐지기 때문입니다.\n");
    return 0;
}
